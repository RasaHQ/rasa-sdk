// @ts-check

const configure = require('@rasahq/docusaurus-tabula/configure');

module.exports = configure({
  /**
   * site
   */
  title: 'Rasa Action Server',
  tagline: 'Rasa Action Server',
  projectName: 'rasa-sdk',
  /**
   * presets
   */
  openApiSpecs: [
    {
      id: 'rasa-sdk-http-api',
      specPath: require.resolve('./static/spec/action-server.yml'),
      pagePath: '/apis/http/',
    },
  ],
  /**
   * plugins
   */

  /**
   * themes
   */
  productLogo: '/img/logo-rasa-oss.png',
  staticDirectories: ['static'],
  // @ts-ignore
  package: require('./package.json'),
});
