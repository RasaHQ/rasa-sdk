# Custom Actions
## Action Server
### choice of sdk
    #### writng yoru own
    #### rasa sdk

in: domain, tracker & next action

what can you do with the tracker

out: list of events

### HTTP API

Tab 

### Rasa SDK
- potentially docstrings/literal includes
- extra info about usage 
#### Action Class
#### Tracker
#### Events
#### Dispatcher
