
import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/docs/rasa-sdk/apis/http/',
    component: ComponentCreator('/docs/rasa-sdk/apis/http/','b86'),
    exact: true
  },
  {
    path: '/docs/rasa-sdk/search/',
    component: ComponentCreator('/docs/rasa-sdk/search/','60c'),
    exact: true
  },
  {
    path: '/docs/rasa-sdk/2.0.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.0.0/','614'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.0.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/','69c'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/about-http-api/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/about-http-api/','cec'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/actions/','a30'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/events/','187'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/knowledge-bases/','250'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/rasa-sdk-changelog/','6fa'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/running-action-server/','614'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/sdk-actions/','b1d'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/sdk-dispatcher/','9b9'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/sdk-events/','ce2'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.0.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.0.0/sdk-tracker/','cee'),
        exact: true,
        'sidebar': "version-2.0.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.2.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.2.0/','12f'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.2.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/','b77'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/about-http-api/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/about-http-api/','71e'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/actions/','46f'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/events/','0d1'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/knowledge-bases/','d8d'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/rasa-sdk-changelog/','e8a'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/running-action-server/','3e3'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/sdk-actions/','adb'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/sdk-dispatcher/','103'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/sdk-events/','902'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.2.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.2.0/sdk-tracker/','3eb'),
        exact: true,
        'sidebar': "version-2.2.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.3.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.3.0/','0c5'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.3.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/','1bc'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/actions/','c6e'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/events/','61b'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/knowledge-bases/','70a'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/rasa-sdk-changelog/','0f6'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/running-action-server/','e1f'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/sdk-actions/','001'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/sdk-dispatcher/','4e5'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/sdk-events/','82c'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.3.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.3.0/sdk-tracker/','273'),
        exact: true,
        'sidebar': "version-2.3.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.4.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.4.0/','e1e'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.4.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/','a8c'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/actions/','58a'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/events/','6a7'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/knowledge-bases/','553'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/rasa-sdk-changelog/','bfa'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/running-action-server/','616'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/sdk-actions/','4c3'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/sdk-dispatcher/','a63'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/sdk-events/','668'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.4.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.4.0/sdk-tracker/','7b7'),
        exact: true,
        'sidebar': "version-2.4.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.5.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.5.0/','b4e'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.5.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/','c55'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/actions/','cd8'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/events/','4dd'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/knowledge-bases/','f52'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/rasa-sdk-changelog/','02c'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/running-action-server/','57f'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/sdk-actions/','936'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/sdk-dispatcher/','fd7'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/sdk-events/','a15'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.5.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.5.0/sdk-tracker/','896'),
        exact: true,
        'sidebar': "version-2.5.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.6.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.6.0/','2fc'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.6.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/','bd4'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/actions/','dd3'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/events/','e09'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/knowledge-bases/','0a9'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/rasa-sdk-changelog/','ecc'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/running-action-server/','dbf'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/sdk-actions/','db7'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/sdk-dispatcher/','dc4'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/sdk-events/','635'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.6.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.6.0/sdk-tracker/','672'),
        exact: true,
        'sidebar': "version-2.6.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.7.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.7.0/','d1c'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.7.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/','1d5'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/actions/','eaa'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/events/','f31'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/knowledge-bases/','54b'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/rasa-sdk-changelog/','4cf'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/running-action-server/','722'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/sdk-actions/','25b'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/sdk-dispatcher/','4ac'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/sdk-events/','e91'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.7.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.7.0/sdk-tracker/','b6f'),
        exact: true,
        'sidebar': "version-2.7.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/2.8.0/',
    component: ComponentCreator('/docs/rasa-sdk/2.8.0/','f36'),
    routes: [
      {
        path: '/docs/rasa-sdk/2.8.0/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/','c62'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/actions/','e0b'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/events/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/events/','7c7'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/knowledge-bases/','8a3'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/rasa-sdk-changelog/','6ed'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/running-action-server/','f43'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/sdk-actions/','1e3'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/sdk-dispatcher/','1a1'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/sdk-events/','ac9'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/2.8.0/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/2.8.0/sdk-tracker/','0c1'),
        exact: true,
        'sidebar': "version-2.8.0/someSidebar"
      }
    ]
  },
  {
    path: '/docs/rasa-sdk/',
    component: ComponentCreator('/docs/rasa-sdk/','d80'),
    routes: [
      {
        path: '/docs/rasa-sdk/',
        component: ComponentCreator('/docs/rasa-sdk/','5f2'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/actions/',
        component: ComponentCreator('/docs/rasa-sdk/actions/','844'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/deploy-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/deploy-action-server/','271'),
        exact: true
      },
      {
        path: '/docs/rasa-sdk/events/',
        component: ComponentCreator('/docs/rasa-sdk/events/','089'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/knowledge-bases/',
        component: ComponentCreator('/docs/rasa-sdk/knowledge-bases/','554'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/rasa-sdk-changelog/',
        component: ComponentCreator('/docs/rasa-sdk/rasa-sdk-changelog/','d8c'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/running-action-server/',
        component: ComponentCreator('/docs/rasa-sdk/running-action-server/','056'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/sdk-actions/',
        component: ComponentCreator('/docs/rasa-sdk/sdk-actions/','1e4'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/sdk-dispatcher/',
        component: ComponentCreator('/docs/rasa-sdk/sdk-dispatcher/','6d8'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/sdk-events/',
        component: ComponentCreator('/docs/rasa-sdk/sdk-events/','6bd'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/sdk-tracker/',
        component: ComponentCreator('/docs/rasa-sdk/sdk-tracker/','b8a'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      },
      {
        path: '/docs/rasa-sdk/validation-action/',
        component: ComponentCreator('/docs/rasa-sdk/validation-action/','ae9'),
        exact: true,
        'sidebar': "version-3.x/someSidebar"
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*')
  }
];
