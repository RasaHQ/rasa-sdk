export default {
  "title": "Rasa Action Server",
  "tagline": "Rasa Action Server",
  "url": "https://rasa.com",
  "baseUrl": "/docs/rasa-sdk/",
  "projectName": "rasa-sdk",
  "staticDirectories": [
    "static",
    "static"
  ],
  "favicon": "img/favicon.ico",
  "noIndex": true,
  "organizationName": "rasahq",
  "baseUrlIssueBanner": true,
  "trailingSlash": true,
  "onBrokenLinks": "ignore",
  "onBrokenMarkdownLinks": "ignore",
  "onDuplicateRoutes": "ignore",
  "presets": [
    [
      "/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/redocusaurus/dist/index.js",
      {
        "specs": [
          {
            "id": "rasa-sdk-http-api",
            "spec": "/Users/lunelson/Git/rasahq/docusaurus-tabula/sites/rasa-sdk/docs/static/spec/action-server.yml",
            "routePath": "/apis/http/"
          }
        ],
        "theme": {}
      }
    ]
  ],
  "plugins": [
    [
      "/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/@docusaurus/plugin-content-docs/lib/index.js",
      {
        "routeBasePath": "/",
        "sidebarPath": "sidebars.js",
        "sidebarCollapsible": true,
        "sidebarCollapsed": true,
        "showLastUpdateAuthor": false,
        "showLastUpdateTime": false,
        "remarkPlugins": [],
        "rehypePlugins": [],
        "beforeDefaultRemarkPlugins": [],
        "beforeDefaultRehypePlugins": [],
        "disableVersioning": false,
        "includeCurrentVersion": false
      }
    ],
    [
      "/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/@docusaurus/plugin-ideal-image/lib/index.js",
      {
        "sizes": [
          160,
          226,
          320,
          452,
          640,
          906,
          1280,
          1810,
          2560
        ],
        "quality": 70
      }
    ],
    "/Users/lunelson/Git/rasahq/docusaurus-tabula/packages/docusaurus-tabula/plugins/plugin-css/index.js"
  ],
  "themeConfig": {
    "colorMode": {
      "disableSwitch": true,
      "defaultMode": "light",
      "respectPrefersColorScheme": false,
      "switchConfig": {
        "darkIcon": "🌜",
        "darkIconStyle": {},
        "lightIcon": "🌞",
        "lightIconStyle": {}
      }
    },
    "metadata": [],
    "navbar": {
      "title": "Rasa Action Server",
      "items": [
        {
          "label": "Rasa Open Source",
          "href": "http://localhost:3000/docs/rasa/",
          "target": "_self",
          "position": "left"
        },
        {
          "label": "Rasa Enterprise",
          "href": "http://localhost:3001/docs/rasa-x/",
          "target": "_self",
          "position": "left"
        },
        {
          "label": "Rasa Action Server",
          "href": "/docs/rasa-sdk/",
          "target": "_self",
          "position": "left"
        },
        {
          "href": "https://github.com/rasahq/rasa-sdk",
          "className": "header-github-link",
          "aria-label": "GitHub repository",
          "position": "right"
        },
        {
          "target": "_self",
          "href": "https://rasa.com/blog/",
          "label": "Blog",
          "position": "right"
        },
        {
          "label": "Community",
          "position": "right",
          "items": [
            {
              "target": "blank",
              "href": "https://rasa.com/community/join/",
              "label": "Community Hub"
            },
            {
              "target": "blank",
              "href": "https://forum.rasa.com",
              "label": "Forum"
            },
            {
              "target": "blank",
              "href": "https://rasa.com/community/contribute/",
              "label": "How to Contribute"
            },
            {
              "target": "blank",
              "href": "https://rasa.com/showcase/",
              "label": "Community Showcase"
            }
          ]
        }
      ],
      "hideOnScroll": false
    },
    "footer": {
      "links": [],
      "copyright": "Copyright © 2022 Rasa Technologies GmbH",
      "style": "light"
    },
    "prism": {
      "defaultLanguage": "shellsession",
      "additionalLanguages": []
    },
    "algolia": {
      "apiKey": "1f9e0efb89e98543f6613a60f847b176",
      "indexName": "rasa",
      "inputSelector": ".search-bar",
      "searchParameters": {
        "facetFilters": [
          "tags:rasa-sdk"
        ]
      }
    },
    "docs": {
      "versionPersistence": "localStorage"
    },
    "hideableSidebar": false,
    "tableOfContents": {
      "minHeadingLevel": 2,
      "maxHeadingLevel": 3
    }
  },
  "customFields": {
    "navbarItems": [
      {
        "target": "_self",
        "href": "https://rasa.com/blog/",
        "label": "Blog",
        "position": "right"
      },
      {
        "label": "Community",
        "position": "right",
        "items": [
          {
            "target": "blank",
            "href": "https://rasa.com/community/join/",
            "label": "Community Hub"
          },
          {
            "target": "blank",
            "href": "https://forum.rasa.com",
            "label": "Forum"
          },
          {
            "target": "blank",
            "href": "https://rasa.com/community/contribute/",
            "label": "How to Contribute"
          },
          {
            "target": "blank",
            "href": "https://rasa.com/showcase/",
            "label": "Community Showcase"
          }
        ]
      }
    ],
    "productLogo": "/img/logo-rasa-oss.png",
    "versionLabels": {
      "current": "Master/Unreleased"
    }
  },
  "themes": [
    "/Users/lunelson/Git/rasahq/docusaurus-tabula/node_modules/@docusaurus/theme-classic/lib/index.js",
    "/Users/lunelson/Git/rasahq/docusaurus-tabula/packages/docusaurus-tabula/themes/algolia-patched/index.js",
    "/Users/lunelson/Git/rasahq/docusaurus-tabula/packages/docusaurus-tabula/themes/classic-swizzled/index.js",
    "/Users/lunelson/Git/rasahq/docusaurus-tabula/packages/docusaurus-tabula/themes/tabula/index.js"
  ],
  "webpack": {},
  "i18n": {
    "defaultLocale": "en",
    "locales": [
      "en"
    ],
    "localeConfigs": {}
  },
  "titleDelimiter": "|"
};